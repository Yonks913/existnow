<!DOCTYPE html>
<html>
<head>
	<title>existnow - Welcome!</title>
	<link type="text/css" rel="stylesheet" href="css/master.css" />
	<link type="text/css" rel="stylesheet" href="css/page/index.css" />
</head>
<body id="top_of_page">
<?php
	include_once ('includes/header.inc.php');
?>
<div class="container">
	<h2 class="page-title">Home</h2>
	<section class="main">
	<h3 class="section-title">Resources</h3>
	<ul class="resources">
		<li>Palettes <a href="http://paletton.com/">http://paletton.com/</a></li>
		<li>light palette http://paletton.com/#uid=13G0u0kqRZSf4ZLliZUyOY+VZVf</li>
		<li>dark palette http://paletton.com/#uid=13G0u0k++UGs5ZVFy+V+Wxz+2pK</li>
	</ul>
	</section>
</div> <!-- end container -->
<footer>
</footer>
<?php
	include_once ('includes/top_of_page.inc.php');
?>
</body>
</html>