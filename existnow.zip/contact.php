<!DOCTYPE html>
<html>
<head>
	<title>existnow - Contact</title>
	<link type="text/css" rel="stylesheet" href="css/master.css" />
</head>
<body id="top_of_page">
<?php
	include_once ('includes/header.inc.php');
?>
<div class="container">
	<h2 class="page-title">Contact</h2>
	<section class="main"> <!-- Header Tags -->
		<h3 class="section-title">Header Tags</h3>
		<div class="content">
			<h1 class="site-title">h1 tag, class="site-title"</h1>
			<h2 class="page-title">h2 tag, class="page-title"</h2>
			<h3 class="section-title">h3 tag, class="section-title"</h3>
			<h4 class="section-subtitle">h4 tag, class="section-subtitle"</h4>
			<h5>h5 tag, class=nul</h5>
			<h6>h6 tag, class=nul</h6>
		</div>
	</section>
	<section class="main"> <!-- Features -->
		<h3 class="section-title">Features</h3>
		<h4 class="section-subtitle">Flip Animation</h4>
		<div class="content">
			<?php
				include_once ('includes/features/flip.inc.php');
			?>
		</div>
		<h4 class="section-subtitle">Flex Box</h4>
		<div class="content row">
			<div class="col">col</div>
			<div class="col">col</div>
		</div>
		<div class="content row">
			<div class="col">col</div>
			<div class="col">col</div>
			<div class="col">col</div>
		</div>
		<div class="content row">
			<div class="col">col</div>
			<div class="col">col</div>
			<div class="col">col</div>
			<div class="col">col</div>
		</div>
		<h4 class="section-subtitle">Perspective Buttons</h4>
		<div class="content flip-menu">
			<div class="flip-button">
				<button class="main-flip">Button 1 long</button><div class="flip">A</div>
			</div>
			<div class="flip-button">
				<button class="main-flip">Button 2 longeeeer</button><div class="flip">B</div>
			</div>
			<div class="flip-button">
				<button class="main-flip">Button 3 longeeeeeeeeer</button><div class="flip">C</div>
			</div>
			<div class="flip-button">
				<button class="main-flip">Button 4 longeeeeeeeeeeeeest</button><div class="flip">D</div>
			</div>
		</div>
	</section>
	<section class="main"> <!-- Palettes -->
		<h3 class="section-title">Palettes</h3>
		<h4 class="section-subtitle">Blue *devcyou.com</h4>
		<p><a href="http://paletton.com/export/index.php">Original</a> (from http://paletton.com/)</p>
		<div class="content">
			<?php
				include_once ('includes/palettes/blue.inc.php');
			?>
		</div>
		<h4 class="section-subtitle">Aqua</h4>
		<div class="content">
			<?php
				include_once ('includes/palettes/aqua.inc.php');
			?>
		</div>
	</section>
</div> <!-- end container -->
<footer>
</footer>
<?php
	include_once ('includes/top_of_page.inc.php');
?>
</body>
</html>