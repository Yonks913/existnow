<!DOCTYPE html>
<html>
<head>
	<title>existnow - About</title>
	<link type="text/css" rel="stylesheet" href="css/master.css" />
</head>
<body id="top_of_page">
<?php
	include_once ('includes/header.inc.php');
?>
<div class="container">
	<h2 class="page-title">About</h2>
	<section class="main">
		<h3 class="section-title">The Author</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eu leo orci. Proin vehicula metus sit amet dolor rhoncus, eu dapibus mauris facilisis. Nam in tortor ac velit vulputate facilisis. Phasellus vel iaculis dui. Nunc consectetur hendrerit consectetur. Vivamus in velit accumsan, suscipit ipsum sed, vehicula arcu. Donec commodo eget nisl vitae aliquet. Integer vitae massa sit amet orci convallis vehicula in a orci. Quisque auctor lacus vitae condimentum rutrum. Morbi sodales in leo a ornare. Morbi malesuada vel eros sed posuere. Etiam vestibulum volutpat mollis. Nunc ut lectus ac augue dignissim fermentum a accumsan nunc. Vivamus tempor dapibus justo, in euismod felis mattis ut.</p>
	</section>
	<section class="main">
		<h3 class="section-title">Caleb</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eu leo orci. Proin vehicula metus sit amet dolor rhoncus, eu dapibus mauris facilisis. Nam in tortor ac velit vulputate facilisis. Phasellus vel iaculis dui. Nunc consectetur hendrerit consectetur. Vivamus in velit accumsan, suscipit ipsum sed, vehicula arcu. Donec commodo eget nisl vitae aliquet. Integer vitae massa sit amet orci convallis vehicula in a orci. Quisque auctor lacus vitae condimentum rutrum. Morbi sodales in leo a ornare. Morbi malesuada vel eros sed posuere. Etiam vestibulum volutpat mollis. Nunc ut lectus ac augue dignissim fermentum a accumsan nunc. Vivamus tempor dapibus justo, in euismod felis mattis ut.</p>
	</section>
	<section class="main">
		<h3 class="section-title">Younker</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eu leo orci. Proin vehicula metus sit amet dolor rhoncus, eu dapibus mauris facilisis. Nam in tortor ac velit vulputate facilisis. Phasellus vel iaculis dui. Nunc consectetur hendrerit consectetur. Vivamus in velit accumsan, suscipit ipsum sed, vehicula arcu. Donec commodo eget nisl vitae aliquet. Integer vitae massa sit amet orci convallis vehicula in a orci. Quisque auctor lacus vitae condimentum rutrum. Morbi sodales in leo a ornare. Morbi malesuada vel eros sed posuere. Etiam vestibulum volutpat mollis. Nunc ut lectus ac augue dignissim fermentum a accumsan nunc. Vivamus tempor dapibus justo, in euismod felis mattis ut.</p>
	</section>
</div> <!-- end container -->
<footer>
</footer>
<?php
	include_once ('includes/top_of_page.inc.php');
?>
</body>
</html>