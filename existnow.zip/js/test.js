var peopleFactory = function(name, age, state){

	var temp ={};
  
  temp.name = name;
  temp.age = age;
  temp.state = state;
  
  temp.printPerson = funtion(){
  	console.log(this.name + ", " + this.age + ", " + this.state + ".");
  };
  
  return temp;

};

var person1 = peopleFactory("Caleb", 19, "CO");
var person2 = peopleFactory("Derek", 20, "NE");

person1.printPerson();
person2.printPerson();