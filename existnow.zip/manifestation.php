<!DOCTYPE html>
<html>
<head>
	<title>existnow - Manifestation</title>
	<link type="text/css" rel="stylesheet" href="css/master.css" />
</head>
<body id="top_of_page">
<?php
	include_once ('includes/header.inc.php');
?>
<div class="container">
	<h2 class="page-title">Manifestation</h2>
	<section class="main">
	
	</section>
</div> <!-- end container -->
<footer>
</footer>
<?php
	include_once ('includes/top_of_page.inc.php');
?>
</body>
</html>