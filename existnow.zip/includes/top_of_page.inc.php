<?php echo
'<div class="top_of_page">
	<a href="#top_of_page"><button class="top_of_page-button">Top of Page</button></a>
</div>';
?>