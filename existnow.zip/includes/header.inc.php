<?php echo
'<header>
<div class="header-container">
	<a href="index.php"><h1 class="site-title">existnow.org</h1></a>
	<nav>
		<div class="nav-menu">
			<a href="index.php"><button class="nav-button">Home</button></a>
			<a href="about.php"><button class="nav-button">About</button></a>
			<a href="manifestation.php"><button class="nav-button">Manifestation</button></a>
			<a href="contact.php"><button class="nav-button">Contact</button></a>
		</div>
	</nav>
</div> <!-- end header-container -->
</header>';
?>